import numpy as np
from scipy import signal


def shi_tomasi(img, patch_size):

