import numpy as np
from scipy import signal


def harris(img, patch_size, kappa):


