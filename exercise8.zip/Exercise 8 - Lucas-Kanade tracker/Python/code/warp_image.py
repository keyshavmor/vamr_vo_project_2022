import numpy as np

def warpImage(image, W):
    """
    Input
        image   np.ndarray 
        W       2 x 3 np.ndarray

    Output
        warped image of the same dimensions
    """

    pass    
