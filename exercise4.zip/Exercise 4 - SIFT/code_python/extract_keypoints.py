import cv2
import numpy as np
import scipy

def extractKeypoints(diff_of_gaussians, contrast_threshold):
    pass
    return keypoint_locations



