import cv2
import numpy as np

def computeBlurredImages(image_pyramid, num_scales, sift_sigma):
   pass 
