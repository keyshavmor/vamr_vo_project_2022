import cv2
import numpy as np

def getGaussianKernel(size, sigma):
    pass

def getImageGradient(image):
    pass

def derotatePatch(img, loc, patch_size, orientation):
    # it can't be worse than a 45 degree rotation, so lets pad 
    # under this assumption. Then it will be enough for sure.
    pass


def computeDescriptors(blurred_images, keypoint_locations, rotation_invariant):
    pass
    # return descriptors, final_keypoint_locations 







