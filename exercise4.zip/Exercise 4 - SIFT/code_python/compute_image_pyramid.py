import cv2

def computeImagePyramid(img, num_octaves):
    pass
