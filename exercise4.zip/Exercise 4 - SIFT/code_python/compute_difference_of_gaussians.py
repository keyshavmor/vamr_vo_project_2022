import cv2
import numpy as np

def computeDifferenceOfGaussians(blurred_images):
    pass


